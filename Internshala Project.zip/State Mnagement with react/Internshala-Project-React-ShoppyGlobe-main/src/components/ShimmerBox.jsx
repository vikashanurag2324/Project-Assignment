function ShimmerBox() {
    return (
        <div className="w-[280px] flex-grow h-[390px] bg-shimmer bg-cover animate-shimmer rounded-lg"></div>
    )
}

export default ShimmerBox;