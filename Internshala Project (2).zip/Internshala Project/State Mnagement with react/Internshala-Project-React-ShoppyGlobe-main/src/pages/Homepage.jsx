import Products from "../components/Products";

function Homepage() {
    return (
        <section>
            <Products />
        </section>
    )
}

export default Homepage;