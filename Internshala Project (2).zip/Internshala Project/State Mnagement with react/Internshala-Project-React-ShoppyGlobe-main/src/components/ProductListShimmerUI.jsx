import ShimmerBox from './ShimmerBox';

function ProductListShimmerUI() {
    return (
        <div className="mt-8 flex flex-wrap gap-x-5 gap-y-10">
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
            <ShimmerBox />
        </div>
    )
}

export default ProductListShimmerUI;